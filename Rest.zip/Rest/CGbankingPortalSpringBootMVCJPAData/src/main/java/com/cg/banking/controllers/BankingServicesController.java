package com.cg.banking.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {

	@Autowired
	BankingServices bankingServices;

	@RequestMapping("/registerAccount")
	public ModelAndView registerAccount(@Valid@ModelAttribute Account account,BindingResult result) {
		if(result.hasErrors())return new ModelAndView("registrationPage");
		account=bankingServices.openAccount(account);
		return new ModelAndView("registrationSuccessPage", "account",account);

	}
	@RequestMapping("/accountDetails")
	public ModelAndView getAccountDetails(@RequestParam long accountNo)throws AccountNotFoundException {
		Account account= bankingServices.getAccountDetails(accountNo);
		return new ModelAndView("findAccountDetailsPage", "account",account);

	}
	@RequestMapping("/depositAmount")
	public ModelAndView depositAmount(@RequestParam long accountNo,@RequestParam float amount)throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		float account= bankingServices.depositAmount(accountNo,amount);
		return new ModelAndView("depositSuccessPage", "account",account);

	}
	@RequestMapping("/withdrawAmount")
	public ModelAndView withdrawAmount(@RequestParam long accountNo, float amount, long pinNumber)throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		float account= bankingServices.withdrawAmount(accountNo,amount,pinNumber);
		return new ModelAndView("withdrawSuccessPage", "account",account);

	}
	@RequestMapping("/moneyTransfer")
	public ModelAndView fundTransfer(@RequestParam long accountNoTo, long accountNoFrom, float transferAmount, long pinNumber)throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		boolean account= bankingServices.fundTransfer(accountNoTo,accountNoFrom,transferAmount,pinNumber);
		return new ModelAndView("fundTransferPage", "account",account);

	}
	@RequestMapping("/allAccountDetails")
	public ModelAndView getAllAccountDetails()throws AccountNotFoundException, BankingServicesDownException {
		java.util.List<Account> account= bankingServices.getAllAccountDetails();
		return new ModelAndView("findAllAccountDetailsPage", "accounts",account);

	}

}


